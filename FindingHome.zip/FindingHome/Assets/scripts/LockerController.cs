﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LockerController : MonoBehaviour {

    void Start()
    {

    }

    void FixedUpdate()
    {

    }

    void OnTriggerEnter2D(Collider2D collider)
    {
    }
}
